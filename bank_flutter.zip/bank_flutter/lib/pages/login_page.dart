

import 'package:bank_flutter/controller/user_controller.dart';
import 'package:bank_flutter/modules/user_module.dart';
import 'package:flutter/material.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _email = new TextEditingController();
  final _pass = new TextEditingController();
  bool _validateEmail = false;
  bool _validateSenha = false;
  bool obscure = true;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _body(context),
    );
  }
  _body(BuildContext context) {
    return Container(
      child: ListView(
        children: [

          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Container(
              child: Column(
                children: [
                  TextField(
                    controller: _email,
                    keyboardType: TextInputType.emailAddress,
                    decoration: InputDecoration(
                      border: new OutlineInputBorder(
                        borderSide: new BorderSide(),
                      ),
                      labelText: 'Email',
                      hintText: 'Email',
                      errorText: _validateEmail ? 'Digite um email' : null,

                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  TextFormField(
                    controller: _pass,
                    obscureText: obscure,
                    decoration: InputDecoration(
                      border: new OutlineInputBorder(
                        borderSide: new BorderSide(),
                      ),
                      suffixIcon: IconButton(
                          alignment: Alignment.bottomLeft,
                          icon: Icon(Icons.remove_red_eye),
                          onPressed: () {
                            setState(() {
                              obscure == true ? obscure = false : obscure =
                              true;
                            });
                          }),
                      labelText: 'Senha',
                      hintText: 'Senha',
                      errorText: _validateSenha ? 'Digite uma senha' : null,
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.fromLTRB(20.0, 15.0, 20.0, 15.0),
                    child: Container(
                      width: MediaQuery
                          .of(context)
                          .size
                          .width / 1.2,
                      child: RaisedButton(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(18.0),
                              side: BorderSide(color: Colors.white)),
                          textColor: Colors.white,
                          child: Padding(
                            padding: const EdgeInsets.all(13.0),
                            child: Text('ENTRAR',
                              style: TextStyle(fontSize: 20),),
                          ),
                          color: Color.fromRGBO(224, 30, 105, 88),
                          onPressed: () {
                            _login();
                          }
                      ),
                    ),
                  ),
                ],
              ),
            ),
          )
        ],
      ),
    );
  }

  void _login() async{
    try{
      User user = User();
      user.username = _email.text;
      user.password = _pass.text;
      /*UserController r = await UserController.login(user);
      print("RES : $r");*/


    }catch(e){

    }
  }
}
