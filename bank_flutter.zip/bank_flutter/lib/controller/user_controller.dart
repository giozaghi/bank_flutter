import 'dart:convert';

import 'package:http/http.dart' as http;

import '../modules/user_module.dart';


class UserController{
  static Future<User> login(User user) async {
    try {
      final url = "https://apidev.ewally.com.br/user/login";

      final headers = {"Content-Type": "application/json"};
      final body = json.encode(user.toJson());

      final response = await http.post(url, headers: headers, body: body);

      final s = response.body;

      final r = User.fromJson(json.decode(s));

      return r;
    } catch (e) {
    }
  }
}